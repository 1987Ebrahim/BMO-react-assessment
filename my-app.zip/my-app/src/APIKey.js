module.exports = {
  APIKey: 'c951ff1'
};
