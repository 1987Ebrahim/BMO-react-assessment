import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <div>
      <nav className="nav">
        <h1>WATCH MOVIES</h1>
        <div>
            <Link to="/">
            </Link>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
