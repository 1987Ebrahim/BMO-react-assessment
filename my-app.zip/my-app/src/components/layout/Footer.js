import React from 'react';

function Footer() {
  return (
    <div class="foot">
      <hr className="foot-hr"/>
      <footer>
      <p>Ebrahim Safdari</p>
      <p>Ebi.Safdari1987@gmail.com</p>
      <p>Number:+1 6478360039</p>
      </footer>
    </div>
  );
}

export default Footer;
